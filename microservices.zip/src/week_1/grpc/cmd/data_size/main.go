package main

import (
//"encoding/json"
//"fmt"
//"github.com/brianvoe/gofakeit"
//"github.com/golang/protobuf/proto"
//
//desc "github.com/xdevspo/go-microservices"
)

func main() {
	//session := &desc.
	//
	//dataJson, _ := json.Marshal(session)
	//fmt.Printf("\n\ndataJson len %d byte \n%v\n", len(dataJson), dataJson)
	//
	//dataPb, _ := proto.Marshal(session)
	//fmt.Printf("dataPb len %d byte \n%v\n", len(dataPb), dataPb)
}
