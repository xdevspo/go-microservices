CREATE TABLE example
(
    id   SERIAL PRIMARY KEY,
    name TEXT NOT NULL
);
